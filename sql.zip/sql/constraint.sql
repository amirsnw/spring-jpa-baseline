ALTER TABLE supplier ADD (
  CONSTRAINT sup_pk PRIMARY KEY (id));